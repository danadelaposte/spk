<?php
header('Location: test'); ?>