<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Pilihan</h1>
                    <p>Pilihan dari Data Kriteria</p>
                </div>
                <div class="col-sm-6">
                    <button type="button" class="mb-3 btn btn-primary float-right" data-toggle="modal" data-target="#exampleModal">
                    <i class="fa fa-plus"></i> Tambah Pilihan
                    </button>
                </div>    
            </div>
            <div class="card-body bg-info">
        
        <!-- <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button> -->
                  <h5><i class="icon fas fa-info"> </i> Info</h5>
                  <h5><b>Kriteria : <?php 
                    foreach ($kriteria as $key => $data) { 
                    echo $data['nama_kriteria'];
                    }
                  ?></b></h5>
                  Silahkan masukkan pilihan dan nilainya
                
        </div>
        </div>
        <!-- /.container-fluid -->
    </section>


    <div class="card card-default">
        
    <!-- /.card-body -->
    </div>
     <!-- /.card -->
          

    <!-- Main content -->
    <section class="content">
        <div class="table-responsive box-body container-fluid">
            <?= $this->session->flashdata('notif') ?>
            <table id="datatable" class="table-sm table-striped table-bordered table-hover" cellspacing="0" width="100%">
                <thead class="text-center bg-secondary">
                    <tr class="text-center">
                        <th class="th-sm">No</th>
                        <th class="th-sm">Nama pilihan</th>
                        <!-- <th class="th-sm">Kriteria</th> -->
                        <th class="th-sm">Nilai Pilihan</th>
                        <th class="th-sm">Action</th>
                    </tr>
                </thead>

                <?php
                $no = 1;
                foreach ($pilihan as $key => $data) { ?>
                    <tr>
                        <td class="text-center"><?= $no++ ?></td>
                        <td><?= $data->nama_pilihan ?></td>
                        <td class="text-center"><?= $data->nilai_pilihan ?></td>
                        <td class="text-center">
                            <form action="<?= base_url('pilihan/hapus') ?>" method="post">
                                <a id="edit_pilihan" data-toggle="modal" data-target="#edit" data-id="<?= $data->id_pilihan ?>" data-nama_pilihan="<?= $data->nama_pilihan ?>" data-nilai_pilihan="<?= $data->nilai_pilihan ?>" class="btn btn-sm btn-success">
                                    <i class="fas fa-pen text-white"></i>
                                </a>
                                <input type="hidden" name="id_pilihan" value="<?= $data->id_pilihan ?>">
                                <button onclick="return confirm('Apakah anda yakin ingin menghapus data ini?')" class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                <?php } ?>
            </table>
        </div>
    </section> <br><br>
    <!-- /.content -->
</div>


<!-- Modal Tambah-->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title" id="exampleModalLabel">Tambah Pilihan</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?= base_url('pilihan/tambah') ?>" method="post" role="form">
                    <div class="form-group">
                        
                        <input type="hidden" class="form-control" id="id_kriteria" name="id_kriteria" value="<?= $id ?>">           
                        <label for="nama_pilihan">Nama Pilihan <span style="color:red">* </span></label>
                        <input type="text" class="form-control" id="nama_pilihan" name="nama_pilihan" required>
                    </div>
                 
                    <div class="form-group">
                        <label for="nilai_pilihan">Nilai Pilihan <span style="color:red">*</span></label>
                        <input type="number" class="form-control" id="nilai_pilihan" name="nilai_pilihan" required>
                    </div>
              
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Keluar</button>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Modal EDIT-->
<div class="modal fade" id="edit" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title" id="exampleModalLabel">Edit Pilihan</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?= base_url('pilihan/edit') ?>" method="post" role="form">
                    <div class="form-group">
                        <input type="hidden" id="id_pilihan_e" name="id_pilihan_e">
                        <label for="nama_e">Nama Pilihan<span style="color:red">*</span></label>
                        <input type="text" class="form-control" id="nama_e" name="nama_e" required>
                    </div>
                    <div class="form-group">
                        <label for="nilai_e">Nilai Pilihan <span style="color:red">*</span></label>
                        <input type="text" class="form-control" id="nilai_e" name="nilai_e" required>
                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Keluar</button>
                <button type="submit" class="btn btn-primary">Simpan</button>
            </div>
            </form>
        </div>
        <script src="<?= base_url() ?>/asset/plugins/jquery/jquery.min.js"></script>
        <script type="text/javascript">
            $(document).on("click", "#edit_pilihan", function() {
                var id_pilihan = $(this).data('id');
                var nama_pilihan = $(this).data('nama_pilihan');
                var nilai = $(this).data('nilai_pilihan');
                
                $(".modal-body #id_pilihan_e").val(id_pilihan);
                $(".modal-body #nama_e").val(nama_pilihan);
                $(".modal-body #nilai_e").val(nilai);
            })
        </script>
    </div>
</div>