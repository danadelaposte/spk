<!-- /.content-wrapper -->

<footer class="main-footer">
    <div class="float-right d-none d-sm-block">
        <b>Version</b> 1.0.0
    </div>
    <strong>Copyright &copy; 2020 <a href="#">Dana Dela Poste</a>.</strong> All rights
    reserved.
</footer>

<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
</aside>
<!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="<?= base_url() ?>/asset/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?= base_url() ?>/asset/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="<?= base_url() ?>/asset/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?= base_url() ?>/asset/dist/js/demo.js"></script>
<!-- dataTables -->
<script src="<?= base_url() ?>asset/plugins/datatables/jquery.dataTables.js"></script>
<script src="<?= base_url() ?>asset/plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>
<script type="text/javascript">
    // $('#datatable').DataTable({
    //     "paging": true,
    //     "lengthChange": false,
    //     "searching": false,
    //     "ordering": true,
    //     "info": true,
    //     "autoWidth": false,
    // });
    $(document).ready(function() {
        $('#datatable').DataTable()
    })
    $(document).ready(function() {
        $('#datatable1').DataTable()
    })
</script>
</body>

</html>