<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Alternatif Cabang</h1>
                    <p>Alternatif untuk pembukaan cabang baru</p>
                </div>
                <div class="col-sm-6">
                    <button type="button" class="mb-3 btn btn-primary float-right" data-toggle="modal" data-target="#exampleModal">
                    <i class="fa fa-plus"></i> Tambah Alternatif
                    </button>
                </div>    
            </div>
            <div class="card-body bg-info">
        
        <!-- <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button> -->
                  <h5><i class="icon fas fa-info"> </i> Info</h5>
                  <h5><b>Cabang : <?php 
                    foreach ($cabang as $key => $data) { 
                    echo $data['nama'];
                    }
                  ?></b></h5>
                  Silahkan tambahkan alternatif
                
        </div>
        </div>
        <!-- /.container-fluid -->
    </section>


    <div class="card card-default">
        
    <!-- /.card-body -->
    </div>
     <!-- /.card -->
          

    <!-- Main content -->
    <section class="content">
        <div class="table-responsive box-body container-fluid">
            <?= $this->session->flashdata('notif') ?>
            <table id="datatable" class="table-sm table-striped table-bordered table-hover" cellspacing="0" width="100%">
                <thead class="text-center bg-secondary">
                    <tr class="text-center">
                        <th class="th-sm">No</th>
                        <th class="th-sm">Nama Alternatif</th>
                        <th class="th-sm">Alamat Alternatif</th>
                        <!-- <th class="th-sm">Masukkan Nilai</th> -->
                        <th class="th-sm">Action</th>
                    </tr>
                </thead>

                <?php
                $no = 1;
                foreach ($v as $key => $data) { ?>
                    <tr>
                        <td class="text-center"><?= $no++ ?></td>
                        <td><?= $data['nama_alt'] ?></td>
                        <td class="text-center"><?= $data['alamat_alt'] ?></td>
                        <!-- <td class="text-center">
                            <form action="<?= base_url('alt_cabang') ?>" method="post">
                                <input type="hidden" name="id" value="<?= $data->id ?>">
                                <button class="btn btn-sm btn-primary"><i class="fas fa-plus"> Tambah Alternatif Cabang</i> </button>
                            </form>
                        </td> -->
                        <td class="text-center">
                            <form action="<?= base_url('alt_cabang/hapus') ?>" method="post">
                                <input type="hidden" name="id_alt_cabang" value="<?= $data['id_alt_cabang'] ?>">
                                <button onclick="return confirm('Apakah anda yakin ingin menghapus data ini?')" class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                <?php } ?>
            </table>
        </div>
    </section> <br><br>
    <!-- /.content -->
</div>


<!-- Modal Tambah-->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title" id="exampleModalLabel">Tambah Pilihan</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?= base_url('pilihan/tambah') ?>" method="post" role="form">
                    <div class="form-group">
                        
                        <input type="hidden" class="form-control" id="id_kriteria" name="id_kriteria" value="<?= $id ?>">           
                        <label for="nama_pilihan">Nama Pilihan <span style="color:red">* </span></label>
                        <input type="text" class="form-control" id="nama_pilihan" name="nama_pilihan" required>
                    </div>
                 
                    <div class="form-group">
                        <label for="nilai_pilihan">Nilai Pilihan <span style="color:red">*</span></label>
                        <input type="number" class="form-control" id="nilai_pilihan" name="nilai_pilihan" required>
                    </div>
              
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Keluar</button>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </div>
        </form>
    </div>
