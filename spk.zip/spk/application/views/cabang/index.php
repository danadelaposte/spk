<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Data Cabang</h1>
                    <p>Data Cabang Pendukung Keputusan</p>
                </div>
                <div class="col-sm-6">
                    <button type="button" class="mb-3 btn btn-primary float-right" data-toggle="modal" data-target="#exampleModal">
                    <i class="fa fa-plus"></i> Tambah Cabang
                    </button>
                </div>    
            </div>
        </div>
        <!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="table-responsive box-body container-fluid">
            <?= $this->session->flashdata('notif') ?>
            <table id="datatable" class="table-sm table-striped table-bordered table-hover" cellspacing="0" width="100%">
                <thead class="text-center bg-secondary">
                    <tr class="text-center">
                        <th class="th-sm">No</th>
                        <th class="th-sm">Nama Cabang</th>
                        <th class="th-sm">Catatan</th>
                        <th class="th-sm">Alternatif</th>
                        <th class="th-sm">Action</th>
                    </tr>
                </thead>

                <?php
                $no = 1;
                foreach ($cabang as $key => $data) { ?>
                    <tr>
                        <td class="text-center"><?= $no++ ?></td>
                        <td><?= $data->nama ?></td>
                        <td><?= $data->catatan ?></td>
                        <td class="text-center">
                            <form action="<?= base_url('alt_cabang') ?>" method="post">
                                <input type="hidden" name="id" value="<?= $data->id ?>">
                                <button class="btn btn-sm btn-primary"><i class="fas fa-plus"> Tambah Alternatif Cabang</i> </button>
                            </form>
                        </td>
                        <td class="text-center">
                            <form action="<?= base_url('cabang/hapus') ?>" method="post">
                                <a id="edit_cabang" data-toggle="modal" data-target="#edit" data-id="<?= $data->id ?>" data-nama="<?= $data->nama ?>" data-catatan="<?= $data->catatan ?>" class="btn btn-sm btn-success">
                                    <i class="fas fa-pen text-white"></i>
                                </a>
                                <input type="hidden" name="id" value="<?= $data->id ?>">
                                <button onclick="return confirm('Apakah anda yakin ingin menghapus data ini?')" class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                <?php } ?>
            </table>
        </div>
    </section> <br><br>
    <!-- /.content -->
</div>


<!-- Modal Tambah-->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title" id="exampleModalLabel">Tambah cabang</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?= base_url('cabang/tambah') ?>" method="post" role="form">
                    <div class="form-group">
                        <label for="nama_cabang">Nama cabang <span style="color:red">*</span></label>
                        <input type="text" class="form-control" id="nama_cabang" name="nama_cabang" required>
                    </div>
                    <div class="form-group">
                        <label for="bobot">Bobot <span style="color:red">*</span></label>
                        <input type="float" class="form-control" id="bobot" name="bobot" required>
                    </div>
                    <div class="form-group">
                        <label for="jenis">Jenis <span style="color:red">*</span></label>
                            <select name="jenis" id="jenis" class="form-control" required>
                                <option value="">- PILIH -</option>
                                <option value="Benefit">Benefit</option>
                                <option value="Cost">Cost</option>
                            </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Keluar</button>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Modal EDIT-->
<div class="modal fade" id="edit" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title" id="exampleModalLabel">Edit cabang</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?= base_url('cabang/edit') ?>" method="post" role="form">
                    <div class="form-group">
                        <input type="hidden" id="id_cabang_e" name="id_cabang_e">
                        <label for="nama_e">Nama cabang<span style="color:red">*</span></label>
                        <input type="text" class="form-control" id="nama_e" name="nama_e" required>
                    </div>
                    <div class="form-group">
                        <label for="bobot_e">Bobot <span style="color:red">*</span></label>
                        <input type="text" class="form-control" id="bobot_e" name="bobot_e" required>
                    </div>
                    <div class="form-group">
                        <label for="jenis_e">Jenis <span style="color:red">*</span></label>
                        <select name="jenis_e" id="jenis_e" class="form-control" required>
                            <option value="">- PILIH -</option>
                            <option value="Benefit">Benefit</option>
                            <option value="Cost">Cost</option>
                        </select>
                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Keluar</button>
                <button type="submit" class="btn btn-primary">Simpan</button>
            </div>
            </form>
        </div>
        <script src="<?= base_url() ?>/asset/plugins/jquery/jquery.min.js"></script>
        <script type="text/javascript">
            $(document).on("click", "#edit_cabang", function() {
                var id_cabang = $(this).data('id');
                var nama_cabang = $(this).data('nama_cabang');
                var bobot = $(this).data('bobot');
                var jenis = $(this).data('jenis');

                $(".modal-body #id_cabang_e").val(id_cabang);
                $(".modal-body #nama_e").val(nama_cabang);
                $(".modal-body #bobot_e").val(bobot);
                $(".modal-body #jenis_e").val(jenis);
            })
        </script>
    </div>
</div>