<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Data Kriteria</h1>
                    <p>Data Kriteria Pendukung Keputusan</p>
                </div>
                <div class="col-sm-6">
                    <button type="button" class="mb-3 btn btn-primary float-right" data-toggle="modal" data-target="#exampleModal">
                    <i class="fa fa-plus"></i> Tambah Kriteria
                    </button>
                </div>    
            </div>
        </div>
        <!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="table-responsive box-body container-fluid">
            <?= $this->session->flashdata('notif') ?>
            <table id="datatable" class="table-sm table-striped table-bordered table-hover" cellspacing="0" width="100%">
                <thead class="text-center bg-secondary">
                    <tr class="text-center">
                        <th class="th-sm">No</th>
                        <th class="th-sm">Nama Kriteria</th>
                        <th class="th-sm">Bobot</th>
                        <th class="th-sm">Pilihan</th>
                        <th class="th-sm">Action</th>
                    </tr>
                </thead>

                <?php
                $no = 1;
                foreach ($kriteria as $key => $data) { ?>
                    <tr>
                        <td class="text-center"><?= $no++ ?></td>
                        <td><?= $data->nama_kriteria ?></td>
                        <td class="text-center"><?= $data->bobot ?></td>
                        <td class="text-center">
                           
                            <form action="<?= base_url('pilihan') ?>" method="post">
                                <input type="hidden" name="id_kriteria" value="<?= $data->id_kriteria ?>">
                                <button class="btn btn-sm btn-primary"><i class="fas fa-plus"> Tambah Pilihan</i> </button>
                            </form>
                        </td>
                        
                        <td class="text-center">
                            <form action="<?= base_url('kriteria/hapus') ?>" method="post">
                                <a id="edit_kriteria" data-toggle="modal" data-target="#edit" data-id="<?= $data->id_kriteria ?>" data-nama_kriteria="<?= $data->nama_kriteria ?>" data-bobot="<?= $data->bobot ?>" data-jenis="<?= $data->jenis ?>" class="btn btn-sm btn-success">
                                    <i class="fas fa-pen text-white"></i>
                                </a>
                                <input type="hidden" name="id_kriteria" value="<?= $data->id_kriteria ?>">
                                <button onclick="return confirm('Apakah anda yakin ingin menghapus data ini?')" class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                <?php } ?>
            </table>
        </div>
    </section> <br><br>
    <!-- /.content -->
</div>


<!-- Modal Tambah-->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title" id="exampleModalLabel">Tambah Kriteria</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?= base_url('kriteria/tambah') ?>" method="post" role="form">
                    <div class="form-group">
                        <label for="nama_kriteria">Nama Kriteria <span style="color:red">*</span></label>
                        <input type="text" class="form-control" id="nama_kriteria" name="nama_kriteria" required>
                    </div>
                    <div class="form-group">
                        <label for="bobot">Bobot <span style="color:red">*</span></label>
                        <input type="float" class="form-control" id="bobot" name="bobot" required>
                    </div>
                    <div class="form-group">
                        <label for="jenis">Jenis <span style="color:red">*</span></label>
                            <select name="jenis" id="jenis" class="form-control" required>
                                <option value="">- PILIH -</option>
                                <option value="Benefit">Benefit</option>
                                <option value="Cost">Cost</option>
                            </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Keluar</button>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Modal EDIT-->
<div class="modal fade" id="edit" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title" id="exampleModalLabel">Edit Kriteria</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?= base_url('kriteria/edit') ?>" method="post" role="form">
                    <div class="form-group">
                        <input type="hidden" id="id_kriteria_e" name="id_kriteria_e">
                        <label for="nama_e">Nama Kriteria<span style="color:red">*</span></label>
                        <input type="text" class="form-control" id="nama_e" name="nama_e" required>
                    </div>
                    <div class="form-group">
                        <label for="bobot_e">Bobot <span style="color:red">*</span></label>
                        <input type="text" class="form-control" id="bobot_e" name="bobot_e" required>
                    </div>
                    <div class="form-group">
                        <label for="jenis_e">Jenis <span style="color:red">*</span></label>
                        <select name="jenis_e" id="jenis_e" class="form-control" required>
                            <option value="">- PILIH -</option>
                            <option value="Benefit">Benefit</option>
                            <option value="Cost">Cost</option>
                        </select>
                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Keluar</button>
                <button type="submit" class="btn btn-primary">Simpan</button>
            </div>
            </form>
        </div>
        <script src="<?= base_url() ?>/asset/plugins/jquery/jquery.min.js"></script>
        <script type="text/javascript">
            $(document).on("click", "#edit_kriteria", function() {
                var id_kriteria = $(this).data('id');
                var nama_kriteria = $(this).data('nama_kriteria');
                var bobot = $(this).data('bobot');
                var jenis = $(this).data('jenis');

                $(".modal-body #id_kriteria_e").val(id_kriteria);
                $(".modal-body #nama_e").val(nama_kriteria);
                $(".modal-body #bobot_e").val(bobot);
                $(".modal-body #jenis_e").val(jenis);
            })
        </script>
    </div>
</div>