<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Data Alternatif</h1>
                    <p>Data Alternatif Pendukung Keputusan</p>
                </div>
                <div class="col-sm-6">
                    <button type="button" class="mb-3 btn btn-primary float-right" data-toggle="modal" data-target="#exampleModal">
                    <i class="fa fa-plus"></i> Tambah Alternatif
                    </button>
                </div>    
            </div>
        </div>
        <!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="table-responsive box-body container-fluid">
            <?= $this->session->flashdata('notif') ?>
            <table id="datatable" class="table-sm table-striped table-bordered table-hover" cellspacing="0" width="100%">
                <thead class="text-center bg-secondary">
                    <tr class="text-center">
                        <th class="th-sm">No</th>
                        <th class="th-sm">Nama Alternatif</th>
                        <th class="th-sm">Alamat</th>
                        <th class="th-sm">Keterangan</th>
                        <th class="th-sm">Foto</th>
                        <th class="th-sm">Action</th>
                    </tr>
                </thead>

                <?php
                $no = 1;
                foreach ($alternatif as $key => $data) { ?>
                    <tr>
                        <td class="text-center"><?= $no++ ?></td>
                        <td><?= $data->nama_alt ?></td>
                        <td class="text-center"><?= $data->alamat_alt ?></td>
                        <td><?= $data->ket_alt ?></td>
                        <td class="text-center">
                        
                        </td>
                        
                        <td class="text-center">
                            <form action="<?= base_url('alternatif/hapus') ?>" method="post">
                                <a id="edit_alternatif" data-toggle="modal" data-target="#edit" data-id_alt="<?= $data->id_alt ?>" data-nama_alt="<?= $data->nama_alt ?>" data-alamat_alt="<?= $data->alamat_alt ?>" data-ket_alt="<?= $data->ket_alt ?>" class="btn btn-sm btn-success">
                                    <i class="fas fa-pen text-white"></i>
                                </a>
                                <input type="hidden" name="id_alt" value="<?= $data->id_alt ?>">
                                <button onclick="return confirm('Apakah anda yakin ingin menghapus data ini?')" class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                <?php } ?>
            </table>
        </div>
    </section> <br><br>
    <!-- /.content -->
</div>


<!-- Modal Tambah-->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title" id="exampleModalLabel">Tambah Alternatif</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?= base_url('alternatif/tambah') ?>" method="post" role="form">
                    <div class="form-group">
                        <label for="nama_alt">Nama Alternatif <span style="color:red">*</span></label>
                        <input type="text" class="form-control" id="nama_alt" name="nama_alt" required>
                    </div>
                    <div class="form-group">
                        <label for="alamat_alt">Alamat <span style="color:red">*</span></label>
                        <input type="text" class="form-control" id="alamat_alt" name="alamat_alt" required>
                    </div>
                    <div class="form-group">
                        <label for="ket_alt">Keterangan <span style="color:red"></label>
                        <input type="text" class="form-control" id="ket_alt" name="ket_alt">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Keluar</button>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Modal EDIT-->
<div class="modal fade" id="edit" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title" id="exampleModalLabel">Edit Alternatif</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?= base_url('alternatif/edit') ?>" method="post" role="form">
                    <div class="form-group">
                        <input type="hidden" id="id_alt_e" name="id_alt_e">
                        <label for="nama_alt_e">Nama Alternatif<span style="color:red">*</span></label>
                        <input type="text" class="form-control" id="nama_alt_e" name="nama_alt_e" required>
                    </div>
                    <div class="form-group">
                        <label for="alamat_alt_e">Alamat <span style="color:red">*</span></label>
                        <input type="text" class="form-control" id="alamat_alt_e" name="alamat_alt_e" required>
                    </div>
                    <div class="form-group">
                        <label for="ket_alt_e">Keterangan <span style="color:red">*</span></label>
                        <input type="text" class="form-control" id="ket_alt_e" name="ket_alt_e">
                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Keluar</button>
                <button type="submit" class="btn btn-primary">Simpan</button>
            </div>
            </form>
        </div>
        <script src="<?= base_url() ?>/asset/plugins/jquery/jquery.min.js"></script>
        <script type="text/javascript">
            $(document).on("click", "#edit_alternatif", function() {
                var id_alt = $(this).data('id_alt');
                var nama_alt = $(this).data('nama_alt');
                var alamat_alt = $(this).data('alamat_alt');
                var ket_alt = $(this).data('ket_alt');

                $(".modal-body #id_alt_e").val(id_alt);
                $(".modal-body #nama_alt_e").val(nama_alt);
                $(".modal-body #alamat_alt_e").val(alamat_alt);
                $(".modal-body #ket_alt_e").val(ket_alt);
            })
        </script>
    </div>
</div>