<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Cabang_m extends CI_Model
{
    public function get()
    {
        $this->db->select('*');
        $this->db->from('cabang');
        $query = $this->db->get()->result();
        return $query;
    }

    public function get_id($id)
    {
        $this->db->select('*');
        $this->db->where('id_cabang',$id);
        $this->db->from('cabang');
        $query = $this->db->get()->result_array();
        return $query;
    }

    public function tambah($data)
    {
        $this->db->insert('cabang', $data);
        return TRUE;
    }
    
    function edit($data, $id)
    {
        $this->db->where('id_cabang', $id);
        $this->db->update('cabang', $data);
        return TRUE;
    }

    public function hapus($id)
    {
      $this->db->where('id_cabang', $id);
      $this->db->delete('cabang');
    }
}
