<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Pilihan_m extends CI_Model
{
    public function get($id)
    {
        $this->db->select('*');
        $this->db->where('id_kriteria',$id);
        $this->db->from('pilihan');
        $query = $this->db->get()->result();
        return $query;
        
    }

    public function tambah($data)
    {
        $this->db->insert('pilihan', $data);
        return TRUE;
    }
    
    function edit($data, $id)
    {
        $this->db->where('id_pilihan', $id);
        $this->db->update('pilihan', $data);
        return TRUE;
    }

    public function hapus($id)
    {
      $this->db->where('id_pilihan', $id);
      $this->db->delete('pilihan');
    }
}
