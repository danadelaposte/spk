<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Subkriteria_m extends CI_Model
{
    public function get()
    {
        $this->db->select('*');
        $this->db->from('v_subkriteria');
        $query = $this->db->get()->result();
        return $query;
        
    }


    public function get_data_by_kriteria_id($id_kriteria) {
        return $this->db->where('id_kriteria', $id_kriteria)->get('subkriteria')->result();
    }

    public function get_c1()
    {
        $this->db->select('*');
        $this->db->where('kode','C1');
        $this->db->from('v_subkriteria');
        $query = $this->db->get()->result_array();
        return $query;
    }

    public function get_c2()
    {
        $this->db->select('*');
        $this->db->where('kode','C2');
        $this->db->from('v_subkriteria');
        $query = $this->db->get()->result_array();
        return $query;
    }

    public function get_c3()
    {
        $this->db->select('*');
        $this->db->where('kode','C3');
        $this->db->from('v_subkriteria');
        $query = $this->db->get()->result_array();
        return $query;
    }

    public function get_c4()
    {
        $this->db->select('*');
        $this->db->where('kode','C4');
        $this->db->from('v_subkriteria');
        $query = $this->db->get()->result_array();
        return $query;
    }

    public function get_c5()
    {
        $this->db->select('*');
        $this->db->where('kode','C5');
        $this->db->from('v_subkriteria');
        $query = $this->db->get()->result_array();
        return $query;
    }

    public function get_c6()
    {
        $this->db->select('*');
        $this->db->where('kode','C6');
        $this->db->from('v_subkriteria');
        $query = $this->db->get()->result_array();
        return $query;
    }

    public function get_c7()
    {
        $this->db->select('*');
        $this->db->where('kode','C7');
        $this->db->from('v_subkriteria');
        $query = $this->db->get()->result_array();
        return $query;
    }
    
    public function tambah($data)
    {
        $this->db->insert('subkriteria', $data);
        return TRUE;
    }
    
    function edit($data, $id)
    {
        $this->db->where('id_subkriteria', $id);
        $this->db->update('subkriteria', $data);
        return TRUE;
    }

    public function hapus($id)
    {
      $this->db->where('id_subkriteria', $id);
      $this->db->delete('subkriteria');
    }
}
