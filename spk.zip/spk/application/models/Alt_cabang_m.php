<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Alt_cabang_m extends CI_Model
{
    public function get_id($id)
    {
        $this->db->select('*');
        $this->db->where('id_cabang',$id);
        $this->db->from('cabang_alternatif');
        $query = $this->db->get()->result_array();
        return $query;
    }

    public function get_add()
    {
        $this->db->select('*');
        $this->db->from('v_cabang_alternatif');
        $query = $this->db->get()->result_array();
        return $query;
    }

    public function tambah($data)
    {
        $this->db->insert('cabang_alternatif', $data);
        return TRUE;
    }
    
    public function hapus($id)
    {
      $this->db->where('id', $id);
      $this->db->delete('cabang_alternatif');
    }
}
