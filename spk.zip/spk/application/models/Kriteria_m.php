<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Kriteria_m extends CI_Model
{
    public function get()
    {
        $this->db->select('*');
        $this->db->from('kriteria');
        $query = $this->db->get()->result();
        return $query;
    }

    // public function get_all()
    // {
    //     $this->db->select('*');
    //     $this->db->from('kriteria');
    //     $query = $this->db->get();
    //     return $query;
    // }

   

    
    function edit($data, $id)
    {
        $this->db->where('id_kriteria', $id);
        $this->db->update('kriteria', $data);
        return TRUE;
    }

}
