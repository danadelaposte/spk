<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Nilai_m extends CI_Model
{
    public function get()
    {
        $this->db->select('*');
        $this->db->from('v_nilai_alt');
        $query = $this->db->get()->result();
        return $query;
    }

    public function get_nilai_by_alternatif($id_alternatif) {
        return $this->db->where('id_alternatif', $id_alternatif)->get('nilai_2')->result();
    }

    public function tambah($data)
    {
        $this->db->insert('nilai', $data);
        return TRUE;
    }
    
    function edit($data, $id)
    {
        $this->db->where('id_subnilai', $id);
        $this->db->update('subnilai', $data);
        return TRUE;
    }

    public function hapus($id)
    {
      $this->db->where('id_subnilai', $id);
      $this->db->delete('subnilai');
    }
}
