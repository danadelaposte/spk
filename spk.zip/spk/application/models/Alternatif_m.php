<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Alternatif_m extends CI_Model
{
    public function get()
    {
        $this->db->select('*, (SELECT COUNT(*) FROM nilai_2 WHERE id_alternatif = alternatif.id_alt ) as count_nilai');
        $this->db->from('alternatif');
        $query = $this->db->get()->result();
        return $query;
    }

    public function get_id($id)
    {
        $this->db->select('*');
        $this->db->where('id_alt',$id);
        $this->db->from('alternatif');
        $query = $this->db->get()->result_array();
        return $query;
    }
    
    public function tambah($data)
    {
        $this->db->insert('alternatif', $data);
        return TRUE;
    }
    
    function edit($data, $id)
    {
        $this->db->where('id_alt', $id);
        $this->db->update('alternatif', $data);
        return TRUE;
    }

    public function hapus($id)
    {
      $this->db->where('id_alt', $id);
      $this->db->delete('alternatif');
    }

    public function get_alternatif_has_nilai() {
        return $this->db
        ->from('alternatif')
        ->where('EXISTS( SELECT * FROM nilai_2 WHERE alternatif.id_alt = nilai_2.id_alternatif)')
        ->get()
        ->result();
    }
}
