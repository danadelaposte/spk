<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Nilai extends CI_Controller
{
	function __construct()
    {
        parent::__construct();
        // check_not_login();
        $this->load->model('subkriteria_m');
        $this->load->model('kriteria_m');
        $this->load->model('alternatif_m');
        $this->load->model('nilai_m');
    }
    

    // baru
    public function create($id) {

        $kriterias = $this->kriteria_m->get();
        
        foreach($kriterias as $kriteria) {
            $kriteria->sub = $this->subkriteria_m->get_data_by_kriteria_id($kriteria->id_kriteria);
        }

        $data['alt']  = $this->alternatif_m->get_id($id);
        $data['datas'] = $kriterias;
		$this->load->view('layout/header');
		$this->load->view('nilai/index_2', $data);
		$this->load->view('layout/footer');
    }

    // baru
    public function ubah($id) {

        $kriterias = $this->kriteria_m->get();
        
        foreach($kriterias as $kriteria) {
            $kriteria->sub = $this->subkriteria_m->get_data_by_kriteria_id($kriteria->id_kriteria);
        }

        $data['alt']  = $this->alternatif_m->get_id($id);
        $data['datas'] = $kriterias;

        $subkriterias = array();
        foreach($this->nilai_m->get_nilai_by_alternatif($id) as $nilai) {
            $subkriterias[$nilai->id_sub_kriteria] = $nilai->id_sub_kriteria;
        }

        $data['nilais'] = $subkriterias;
        $data['id'] = $id;

        // print_r($data);die;

		$this->load->view('layout/header');
		$this->load->view('nilai/edit', $data);
		$this->load->view('layout/footer');
    }

    public function update() {
        $alt_id = $this->input->post('id_alt');

        $this->db->where('id_alternatif', $alt_id)->delete('nilai_2');

        foreach($this->input->post('sub_kriteria') as $sub_id) {
            $this->db->insert('nilai_2', array(
                'id_alternatif'     => $alt_id,
                'id_sub_kriteria'   => $sub_id
            ));
        }

        if ($this->db->affected_rows() > 0) {
            $this->session->set_flashdata('notif', '<div class="alert alert-success" role="alert"> 
            Data Berhasil di ubah <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
            redirect("/alternatif");
        } else {
            $this->session->set_flashdata('notif', '<div class="alert alert-warning" role="alert"> 
            Data GAGAL di ubah <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
            redirect("/alternatif");
        }
    }

    public function tambah_2() {

        $alt_id = $this->input->post('id_alt');

        foreach($this->input->post('sub_kriteria') as $sub_id) {
            $this->db->insert('nilai_2', array(
                'id_alternatif'     => $alt_id,
                'id_sub_kriteria'   => $sub_id
            ));
        }

        if ($this->db->affected_rows() > 0) {
            $this->session->set_flashdata('notif', '<div class="alert alert-success" role="alert"> 
            Data Berhasil ditambahkan <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
            redirect("/alternatif");
        } else {
            $this->session->set_flashdata('notif', '<div class="alert alert-warning" role="alert"> 
            Data GAGAL ditambahkan <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
            redirect("/alternatif");
        }
    }
	
	public function index()
	{
        $id = $this->input->post('id_alt');
        $query_alt = $this->alternatif_m->get_id($id);
		$sub_c1 = $this->subkriteria_m->get_c1();
		$sub_c2 = $this->subkriteria_m->get_c2();
		$sub_c3 = $this->subkriteria_m->get_c3();
		$sub_c4 = $this->subkriteria_m->get_c4();
		$sub_c5 = $this->subkriteria_m->get_c5();
		$sub_c6 = $this->subkriteria_m->get_c6();
		$sub_c7 = $this->subkriteria_m->get_c7();
        $data = array(
            'alt' => $query_alt,
            'sub_c1' => $sub_c1,
            'sub_c2' => $sub_c2,
            'sub_c3' => $sub_c3,
            'sub_c4' => $sub_c4,
            'sub_c5' => $sub_c5,
            'sub_c6' => $sub_c6,
            'sub_c7' => $sub_c7
        );

		$this->load->view('layout/header');
		$this->load->view('nilai/index', $data);
		$this->load->view('layout/footer');
	}


	public function tambah()
    {

        $id_alt = $this->input->post('id_alt');
        $data = array(
            'id_alt' => $id_alt,
            'c1' => $this->input->post('id_sub_c1'),
            'c2' => $this->input->post('id_sub_c2'),
            'c3' => $this->input->post('id_sub_c3'),
            'c4' => $this->input->post('id_sub_c4'),
            'c5' => $this->input->post('id_sub_c5'),
            'c6' => $this->input->post('id_sub_c6'),
            'c7' => $this->input->post('id_sub_c7'),
        );
		$this->nilai_m->tambah($data);
		
        if ($this->db->affected_rows() > 0) {
            $this->session->set_flashdata('notif', '<div class="alert alert-success" role="alert"> 
            Data Berhasil ditambahkan <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
            echo "<script>window.location='" . base_url('alternatif') . "';</script>";
        } else {
            $this->session->set_flashdata('notif', '<div class="alert alert-warning" role="alert"> 
            Data GAGAL ditambahkan <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
            echo "<script>window.location='" . base_url('alternatif') . "';</script>";
        }
	}
	
	public function edit()
    {
        $id = $this->input->post('id_subnilai_e');
        $data = array(
            'nama_subnilai' => $this->input->post('nama_e'),
            'nilai_subnilai' => $this->input->post('nilai_e'),
        );
     
		$this->subnilai_m->edit($data, $id);
		
        $this->session->set_flashdata('notif', '<div class="alert alert-success" role="alert"> 
        Data Berhasil diubah <button type="button" class="close" data-dismiss="alert" 
        aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
        echo "<script>window.location='" . base_url('nilai') . "';</script>";
	}

	public function hapus()
    {
        $id = $this->input->post('id_subnilai');
        $this->subnilai_m->hapus($id);

        if ($this->db->affected_rows() > 0) {
            $this->session->set_flashdata('notif', '<div class="alert alert-success" role="alert"> 
            Data berhasil dihapus <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
            echo "<script>window.location='" . base_url('nilai') . "';</script>";
        } else {
            $this->session->set_flashdata('notif', '<div class="alert alert-warning" role="alert"> 
            Data GAGAL dihapus <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
            echo "<script>window.location='" . base_url('nilai') . "';</script>";
		}
	}
	
}
