<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Alternatif extends CI_Controller
{
	function __construct()
    {
        parent::__construct();
        // check_not_login();
        $this->load->model('alternatif_m');
        // $this->load->model('nilai_m');
	}
	
	public function index()
	{
        $query = $this->alternatif_m->get();
        // $cek = $this->nilai_m->get();
		$data = array (
            'alternatif' => $query,
            // 'cek' => $cek
        );
		$this->load->view('layout/header');
		$this->load->view('alternatif/index', $data);
		$this->load->view('layout/footer');
	}

	public function tambah()
    {
        $data = array(
            'nama_alt' => $this->input->post('nama_alt'),
            'alamat_alt' => $this->input->post('alamat_alt'),
            'ket_alt' => $this->input->post('ket_alt')
        );
		$this->alternatif_m->tambah($data);
		
        if ($this->db->affected_rows() > 0) {
            $this->session->set_flashdata('notif', '<div class="alert alert-success" role="alert"> 
            Data Berhasil ditambahkan <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
            echo "<script>window.location='" . base_url('alternatif') . "';</script>";
        } else {
            $this->session->set_flashdata('notif', '<div class="alert alert-warning" role="alert"> 
            Data GAGAL ditambahkan <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
            echo "<script>window.location='" . base_url('alternatif') . "';</script>";
        }
	}
	
	public function edit()
    {
        $id = $this->input->post('id_alt_e');
        $data = array(
            'nama_alt' => $this->input->post('nama_alt_e'),
            'alamat_alt' => $this->input->post('alamat_alt_e'),
            'ket_alt' => $this->input->post('ket_alt_e'),
        );
     
		$this->alternatif_m->edit($data, $id);
		
        $this->session->set_flashdata('notif', '<div class="alert alert-success" role="alert"> 
        Data Berhasil diubah <button type="button" class="close" data-dismiss="alert" 
        aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
        echo "<script>window.location='" . base_url('alternatif') . "';</script>";
	}

	public function hapus()
    {
        $id = $this->input->post('id_alt');
        $this->alternatif_m->hapus($id);

        if ($this->db->affected_rows() > 0) {
            $this->session->set_flashdata('notif', '<div class="alert alert-success" role="alert"> 
            Data berhasil dihapus <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
            echo "<script>window.location='" . base_url('alternatif') . "';</script>";
        } else {
            $this->session->set_flashdata('notif', '<div class="alert alert-warning" role="alert"> 
            Data GAGAL dihapus <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
            echo "<script>window.location='" . base_url('alternatif') . "';</script>";
		}
    }
	
}
