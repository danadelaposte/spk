<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Subkriteria extends CI_Controller
{
	function __construct()
    {
        parent::__construct();
        // check_not_login();
        $this->load->model('subkriteria_m');
        $this->load->model('kriteria_m');
	}
	
	public function index()
	{
        $query_pil = $this->subkriteria_m->get();
		$query_kri = $this->kriteria_m->get();
        $data = array(
            'subkriteria' => $query_pil,
            'kriteria' => $query_kri
        );
		$this->load->view('layout/header');
		$this->load->view('subkriteria/index', $data);
		$this->load->view('layout/footer');
	}

	public function tambah()
    {
        $data = array(
            'id_kriteria' => $this->input->post('id_kriteria'),
            'nama_subkriteria' => $this->input->post('nama_subkriteria'),
            'nilai_subkriteria' => $this->input->post('nilai_subkriteria'),
            'keterangan' => $this->input->post('keterangan')
        );
		$this->subkriteria_m->tambah($data);
		
        if ($this->db->affected_rows() > 0) {
            $this->session->set_flashdata('notif', '<div class="alert alert-success" role="alert"> 
            Data Berhasil ditambahkan <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
            echo "<script>window.location='" . base_url('subkriteria') . "';</script>";
        } else {
            $this->session->set_flashdata('notif', '<div class="alert alert-warning" role="alert"> 
            Data GAGAL ditambahkan <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
            echo "<script>window.location='" . base_url('subkriteria') . "';</script>";
        }
	}
	
	public function edit()
    {
        $id = $this->input->post('id_subkriteria_e');
        $data = array(
            'id_kriteria' => $this->input->post('id_kriteria_e'),
            'nama_subkriteria' => $this->input->post('nama_sub_e'),
            'nilai_subkriteria' => $this->input->post('nilai_subkriteria_e'),
            'keterangan' => $this->input->post('keterangan_e'),
        );
     
		$this->subkriteria_m->edit($data, $id);
		
        $this->session->set_flashdata('notif', '<div class="alert alert-success" role="alert"> 
        Data Berhasil diubah <button type="button" class="close" data-dismiss="alert" 
        aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
        echo "<script>window.location='" . base_url('subkriteria') . "';</script>";
	}

	public function hapus()
    {
        $id = $this->input->post('id_subkriteria');
        $this->subkriteria_m->hapus($id);

        if ($this->db->affected_rows() > 0) {
            $this->session->set_flashdata('notif', '<div class="alert alert-success" role="alert"> 
            Data berhasil dihapus <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
            echo "<script>window.location='" . base_url('subkriteria') . "';</script>";
        } else {
            $this->session->set_flashdata('notif', '<div class="alert alert-warning" role="alert"> 
            Data GAGAL dihapus <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
            echo "<script>window.location='" . base_url('subkriteria') . "';</script>";
		}
	}
	
}
