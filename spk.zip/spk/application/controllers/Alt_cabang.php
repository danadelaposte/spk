<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Alt_cabang extends CI_Controller
{
	function __construct()
    {
        parent::__construct();
        // check_not_login();
        $this->load->model('alt_cabang_m');
        $this->load->model('alternatif_m');
        $this->load->model('cabang_m');
        // $this->load->model('nilai_m');
	}
	
	public function index()
	{
        $id = $this->input->post('id');

        // $query = $this->alt_cabang_m->get_id($id);
        $data = array(
            // 'v' => $query,
            'cabang' => $this->cabang_m->get_id($id),
            'alt_cabang' => $this->alt_cabang_m->get_add(),
            'alternatifs'   => $this->alternatif_m->get_alternatif_has_nilai()
        );

		$this->load->view('layout/header');
		$this->load->view('alt_cabang/index', $data);
		$this->load->view('layout/footer');
	}

	public function tambah()
    {

        $data = array(
            'id_cabang' => $this->input->post('id_cabang'),
            'id_alternatif' => $this->input->post('id_alternatif')
        );
		$this->alt_cabang_m->tambah($data);
		
        if ($this->db->affected_rows() > 0) {
            $this->session->set_flashdata('notif', '<div class="alert alert-success" role="alert"> 
            Data Berhasil ditambahkan <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
            echo "<script>window.location='" . base_url('cabang') . "';</script>";
        } else {
            $this->session->set_flashdata('notif', '<div class="alert alert-warning" role="alert"> 
            Data GAGAL ditambahkan <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
            echo "<script>window.location='" . base_url('cabang') . "';</script>";
        }
	}
	

	public function hapus()
    {
        $id = $this->input->post('id');
        $this->alt_cabang_m->hapus($id);

        if ($this->db->affected_rows() > 0) {
            $this->session->set_flashdata('notif', '<div class="alert alert-success" role="alert"> 
            Data berhasil dihapus <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
            echo "<script>window.location='" . base_url('cabang') . "';</script>";
        } else {
            $this->session->set_flashdata('notif', '<div class="alert alert-warning" role="alert"> 
            Data GAGAL dihapus <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
            echo "<script>window.location='" . base_url('cabang') . "';</script>";
		}
	}
	
}
