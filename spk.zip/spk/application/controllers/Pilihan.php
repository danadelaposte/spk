<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Pilihan extends CI_Controller
{
	function __construct()
    {
        parent::__construct();
        // check_not_login();
        $this->load->model('pilihan_m');
        $this->load->model('kriteria_m');
	}
	
	public function index()
	{
        $id = $this->input->post('id_kriteria');
        $query_pil = $this->pilihan_m->get($id);
		$query_kri = $this->kriteria_m->get_id($id);
        // $data['pilihan'] = $query;
        // $pilihan = array($data,$id);
        $data = array(
            'pilihan' => $query_pil,
            'id' => $id,
            'kriteria' => $query_kri
        );
		$this->load->view('layout/header');
		$this->load->view('pilihan/index', $data);
		$this->load->view('layout/footer');
	}

	public function tambah()
    {

        $id_kriteria = $this->input->post('id_kriteria');
        $data = array(
            'nama_pilihan' => $this->input->post('nama_pilihan'),
            'id_kriteria' => $id_kriteria,
            'nilai_pilihan' => $this->input->post('nilai_pilihan')
        );
		$this->pilihan_m->tambah($data);
		
        if ($this->db->affected_rows() > 0) {
            $this->session->set_flashdata('notif', '<div class="alert alert-success" role="alert"> 
            Data Berhasil ditambahkan <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
            echo "<script>window.location='" . base_url('kriteria') . "';</script>";
        } else {
            $this->session->set_flashdata('notif', '<div class="alert alert-warning" role="alert"> 
            Data GAGAL ditambahkan <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
            echo "<script>window.location='" . base_url('kriteria') . "';</script>";
        }
	}
	
	public function edit()
    {
        $id = $this->input->post('id_pilihan_e');
        $data = array(
            'nama_pilihan' => $this->input->post('nama_e'),
            'nilai_pilihan' => $this->input->post('nilai_e'),
        );
     
		$this->pilihan_m->edit($data, $id);
		
        $this->session->set_flashdata('notif', '<div class="alert alert-success" role="alert"> 
        Data Berhasil diubah <button type="button" class="close" data-dismiss="alert" 
        aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
        echo "<script>window.location='" . base_url('kriteria') . "';</script>";
	}

	public function hapus()
    {
        $id = $this->input->post('id_pilihan');
        $this->pilihan_m->hapus($id);

        if ($this->db->affected_rows() > 0) {
            $this->session->set_flashdata('notif', '<div class="alert alert-success" role="alert"> 
            Data berhasil dihapus <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
            echo "<script>window.location='" . base_url('kriteria') . "';</script>";
        } else {
            $this->session->set_flashdata('notif', '<div class="alert alert-warning" role="alert"> 
            Data GAGAL dihapus <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
            echo "<script>window.location='" . base_url('kriteria') . "';</script>";
		}
	}
	
}
