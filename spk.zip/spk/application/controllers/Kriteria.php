<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Kriteria extends CI_Controller
{
	function __construct()
    {
        parent::__construct();
        // check_not_login();
        $this->load->model('kriteria_m');
	}
	
	public function index()
	{
		$query = $this->kriteria_m->get();
		$data['kriteria'] = $query;
		
		$this->load->view('layout/header');
		$this->load->view('kriteria/index', $data);
		$this->load->view('layout/footer');
	}

	
	public function edit()
    {
        $id = $this->input->post('id_kriteria_e');
        $data = array(
            'keterangan' => $this->input->post('keterangan_e'),
            'bobot' => $this->input->post('bobot_e')
        );
		$this->kriteria_m->edit($data, $id);
		
        $this->session->set_flashdata('notif', '<div class="alert alert-success" role="alert"> 
        Data Berhasil diubah <button type="button" class="close" data-dismiss="alert" 
        aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
        echo "<script>window.location='" . base_url('kriteria') . "';</script>";
	}

	
}
