<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Cabang extends CI_Controller
{
	function __construct()
    {
        parent::__construct();
        // check_not_login();
        $this->load->model('cabang_m');
	}
	
	public function index()
	{
        $query = $this->cabang_m->get();
		$data['cabang'] = $query;
		
		$this->load->view('layout/header');
		$this->load->view('cabang/index', $data);
		$this->load->view('layout/footer');
	}

	public function tambah()
    {

        $data = array(
            'nama_cabang' => $this->input->post('nama_cabang'),
            'catatan' => $this->input->post('catatan')
        );
		$this->cabang_m->tambah($data);
		
        if ($this->db->affected_rows() > 0) {
            $this->session->set_flashdata('notif', '<div class="alert alert-success" role="alert"> 
            Data Berhasil ditambahkan <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
            echo "<script>window.location='" . base_url('cabang') . "';</script>";
        } else {
            $this->session->set_flashdata('notif', '<div class="alert alert-warning" role="alert"> 
            Data GAGAL ditambahkan <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
            echo "<script>window.location='" . base_url('cabang') . "';</script>";
        }
	}
	
	public function edit()
    {
        $id = $this->input->post('id_cabang_e');
        $data = array(
            'nama_cabang' => $this->input->post('nama_e'),
            'catatan' => $this->input->post('catatan_e'),
        );
     
		$this->cabang_m->edit($data, $id);
		
        $this->session->set_flashdata('notif', '<div class="alert alert-success" role="alert"> 
        Data Berhasil diubah <button type="button" class="close" data-dismiss="alert" 
        aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
        echo "<script>window.location='" . base_url('cabang') . "';</script>";
	}

	public function hapus()
    {
        $id = $this->input->post('id_cabang');
        $this->cabang_m->hapus($id);

        if ($this->db->affected_rows() > 0) {
            $this->session->set_flashdata('notif', '<div class="alert alert-success" role="alert"> 
            Data berhasil dihapus <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
            echo "<script>window.location='" . base_url('cabang') . "';</script>";
        } else {
            $this->session->set_flashdata('notif', '<div class="alert alert-warning" role="alert"> 
            Data GAGAL dihapus <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
            echo "<script>window.location='" . base_url('cabang') . "';</script>";
		}
	}
	
}
